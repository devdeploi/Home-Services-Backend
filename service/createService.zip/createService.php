<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight requests for CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200); // Return HTTP status 200 OK for preflight requests
    exit();
}

include '../inc/dbcon.php';

//  $targetDir = "D:/New folder/MyServiceApp/src/assets/uploads";
 $targetDir = "/generalservices/assests/";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['serv_name']) && !empty($_POST['serv_name']) && isset($_FILES['image'])) {
        // Sanitize input
        $serv_name = mysqli_real_escape_string($conn, $_POST['serv_name']);
        $image = $_FILES['image']['name'];
        $tempName = $_FILES["image"]["tmp_name"];

        // Set up file variables
        $imgExt = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

        // Check if file type is allowed
        if (in_array($imgExt, $allowedTypes)) {
            // Generate unique filename to avoid overwrites
            $originalFilename = pathinfo($image, PATHINFO_FILENAME);
            $filename = file_exists($targetDir . $image)
                ? $originalFilename . '_' . time() . '.' . $imgExt
                : $image;

            $targetFilePath = $targetDir . $filename;
            // $imagePath = $baseUrl . $filename;
            $imagePath =  $filename;
            
            // Move the uploaded file
            if (move_uploaded_file($tempName, $targetFilePath)) {
                // Insert service data into the database
                $sql = "INSERT INTO serv_type (serv_name, image) VALUES ('$serv_name', '$imagePath')";
                if (mysqli_query($conn, $sql)) {
                    $serv_id = mysqli_insert_id($conn);
                    $data = [
                        'status' => 200,
                        'message' => 'Service Created Successfully',
                        'serv_id' => $serv_id,
                        'serv_name' => $serv_name,
                        'image_url' => $imagePath // Full URL of the uploaded image
                    ];
                    echo json_encode($data);
                } else {
                    // Database insertion error
                    $data = [
                        'status' => 500,
                        'message' => 'Internal Server Error: ' . mysqli_error($conn)
                    ];
                    echo json_encode($data);
                }
            } else {
                // File upload failure
                $data = [
                    'status' => 500,
                    'message' => 'Failed to upload image'
                ];
                echo json_encode($data);
            }
        } else {
            // Invalid file type
            $data = [
                'status' => 400,
                'message' => 'Invalid file type. Allowed types: jpg, jpeg, png, gif'
            ];
            echo json_encode($data);
        }
    } else {
        // Missing service name or image
        $data = [
            'status' => 400,
            'message' => 'Service name and image file are required'
        ];
        echo json_encode($data);
    }
} else {
    // Method not allowed
    $data = [
        'status' => 405,
        'message' => $_SERVER["REQUEST_METHOD"] . ' Method Not Allowed'
    ];
    echo json_encode($data);
}
?>

